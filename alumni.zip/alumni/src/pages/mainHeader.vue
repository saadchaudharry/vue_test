<template>
    <div class="flex fixed top-0 w-screen items-center justify-between bg-magicbus_primary p-4 ">

        <div class="text-lg font-bold text-gray-800">
            <img src="" alt="Logo" class="">
        </div>

        <button class="sidebar-toggle block md:hidden text-gray-800" onclick="toggleSidebar()">
            <span class="material-icons">menu</span>
        </button>

    </div>
</template>

<script setup>

</script>

<style>
</style>